#!/data/data/com.termux/files/usr/bin/bash
clear
DIR=`cd $(dirname $0) && pwd`
FONTS_DIR=$DIR/fonts
count=0
echo "▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄"  |  lolcat
echo -e "Multi Font Charger For Fonts Shell\nYou can choose another one from list below.\nCode By : Sahrul Gunawan Cyber\nInstagram : Wes_Kadung_Rewel\nWhatsapp : +6281333166254";
echo "▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄"  |  lolcat
for font in $FONTS_DIR/*/{*.ttf,*.otf}; do
	font_file[count]=$font;
	echo "[$count] $( echo ${font_file[count]} | awk -F'/' '{print $NF}' )";
	count=$(( $count + 1));
done;
count=$(( $count - 1 ));

while true; do
        echo "▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄"  |  lolcat
        echo "TEKAN ENTER SAJA OTOMATIS AKAN MENGGANTI FONT DEFAULT"
        echo "▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄"  |  lolcat
	read -p '(Root@SahrulGunawan)~(Pilih Nomor)> ' number;

	if [[ -z "$number" ]]; then
		break;
	elif ! [[ $number =~ ^[0-9]+$ ]]; then
		echo "Please enter the right number.";
	elif (( $number >= 0 && $number <= $count )); then
		cp -fr "${font_file[number]}" "$DIR/font.ttf";
		break;
	else
		echo "Please enter the right number.";
	fi
done;

termux-reload-settings
